#ifndef  FILA_VETOR_TAMANHO_FIXO_H
#define  FILA_VETOR_TAMANHO_FIXO_H


    void CriarFila();
    void InserirFila();
    void RemoverFila();
    void FilaCheia();
    void FilaVazia();
    void TamanhoFila();
    void ImprimirFila();

#endif

