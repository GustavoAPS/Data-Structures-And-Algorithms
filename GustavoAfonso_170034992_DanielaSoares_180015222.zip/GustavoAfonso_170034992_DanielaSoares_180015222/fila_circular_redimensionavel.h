#ifndef  FILA_CIRCULAR_REDIMENSIONAL_H
#define  FILA_CIRCULAR_REDIMENSIONAL_H

    //int fim;

    int  CriarFila();
    int InserirFila();
    int RemoverFila();
    int FilaCheia();
    int FilaVazia();
    int  TamanhoFila();
    void ImprimirFila();


#endif
