#ifndef  FILA_LISTA_ENCADEADA_H
#define  FILA_LISTA_ENCADEADA_H

    void CriarFila();
    void InserirFila();
    void RemoverFila();
    void FilaCheia();
    void FilaVazia();
    void TamanhoFila();
    void ImprimirFila();

#endif
